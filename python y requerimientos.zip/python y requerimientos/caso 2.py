
#Caso de Estudio 2: Programa Calculadora de adso
#Objetivo: Crear un SCRIPT con requerimientos funcionales, no funcionales y sus interfaces
#necesarias para un sistema que proyecte una calculadora con los siguientes procesos.
#• Operaciones Básicas (suma, resta, multiplicación, división).
#• Operaciones Numéricas (Decimal a binario, Binario a decimal).
#• Conversión de temperatura (Celsius a Fahrenheit).
#• IMC.
#• Conversión de unidades de medida (cm a mt, mt a cm, mt a km, km a mt).
#• Conversión de unidades de tiempo (Segundos a minutos, minutos a horas, horas a minutos
#y segundos). Creador: Edwar Farid Gomez



print(""" Bienvienido a la calculadora de ADSO \n 1.Operacion \n 2.Conversion \n 3.IMC""")

opcion = int (input())

if opcion == 1:

        num1=int(input("Ingrese el primer número:"))
        num2=int(input("Ingrese el segundo número:"))



        while print(""" Selecciona la operacion que deseas realizar
                            1. Suma
                            2. Resta
                            3. Multiplicacion
                            4. Division """):
            break

        eleccion = 0

        eleccion != 6

        eleccion = int(input())

        if eleccion == 1:
            print(" ")
            print("Resultado: ", num1, "+", num2, "=", num1+num2)

        if eleccion == 2:
            print(" ")
            print("Resultado: ", num1, "-", num2, "=" , num1-num2)

        if eleccion == 3:
            print(" ")
            print("Resultado: ", num1, "*", num2, "=", num1*num2)

        if eleccion == 4:
            print(" ")
            print("Resultado: ", num1, "/", num2, "=" , num1/num2)


elif opcion == 2:

        num=int(input("Ingrese el numero que desea convertir:"))
        while print(""" Selecciona la conversion que deseas realizar
                            1. Decimal - Binario
                            2. binario - Decimal
                            3. Celsius - Fahrenheit
                            4. Cm - Mt
                            5. Mt - cm
                            6. Mt - km
                            7. Km - Mt
                            8. Segundo - Minutos
                            9. Minutos - horas
                            10. horas - Minutos
                            """):
            break
        conversion = 0
        conversion != 11
        conversion = int(input())
        if conversion == 1:
            a = num
            bin_a = bin(a)
            print("tu decimal en binario es :" ,bin_a, 2 )
        if conversion == 2:
            decimal = 0
            i = 0
            while (num>0):
                digito  = num%10
                num = int(num//10)
                decimal = decimal+digito*(2**i)
                i = i+1
                print("Tu binario en decimal es: ",decimal)
        if conversion == 3:
                    print(" ")
                    print( num, " Grados Celsius son ",  9.0/5.0 * num +32, " grados Fahrenheit")
        if conversion == 4:
                    print(" ")
                    print( num, " Centimentros son ",  num*100 , " Metros")
        if conversion == 5:
                    print(" ")
                    print( num, " Metros son ",  num*100 , " Metros")
        if conversion == 6:
                    print(" ")
                    print( num, " Metros son ",  num/1000 , " kilometros")
        if conversion == 7:
                    print(" ")
                    print( num, " Kilometros son ",  num*1000 , " Metros")
        if conversion == 8 : #segundos a minutos
                    print (" ")
                    print ( num, " Segundos son ", num/60 , " Minutos")
        if conversion == 9 : #minutos a horas y horas a minutos
                    print (" ")
                    print ( num, " Minutos son ", num/60 , " Horas")
        if conversion == 10 : #Horas a minutos
                    print (" ")
                    print  (num, " Horas son " , num*60, " Minutos " )
elif opcion == 3:

    peso = float(input("Ingrese su peso en Kilogramos: "))
    estatura = float(input("Ingrese su estatura en metros: "))

IMC = round(peso/math.pow(estatura,2),1)

print("Su IMC es de "+str(IMC))

lista = [["Composición corporal","Índice de masa corporal (IMC)"],["Peso inferior al normal","Menos de 18.5"],["Normal","18.5 – 24.9"],["Peso superior al normal","25.0 – 29.9"],["Obesidad","Más de 30.0"]]

print(tabulate(lista))



new_var = 1
new_var