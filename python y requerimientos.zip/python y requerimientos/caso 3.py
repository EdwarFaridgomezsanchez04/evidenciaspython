# Empezamos colocando el número de camiones diarios que la empresa pide, que en este caso son 20
numerocamiones = 20
for i in range(numerocamiones):
    capacidadcamion = float(input("Bienvenido operario, porfavor digite la capacidad del camion"+ str(i+1) +"El rango debe ser de 18000 kg y 28000 kg: "))
    #Luego colocamos concionales para mirar si la capacidad del camion es la permitida
    if capacidadcamion <18000 or capacidadcamion >28000:
            #Si no cumple con la capacidad necesaria se imprime un mensaje que le dice al operario que no cumple con la capacidad permitida
            print("Lastimosamente la capacidad del camión excede los límites... intente más rato.")
            continue
    # Inicializar el peso actual del camion
    pesoactualcamion = 0
    while True:
            pesosaca = float(input("Por favor ingrese el peso de la saca, el rango está entre 3000 kg y 9000 kg: "))
             # Verificar que el peso de la saca esté dentro del rango permitido
            if pesosaca < 3000 or pesosaca > 9000:
                print("Lastimosamente se excedió de los límites de peso de la saca, intente más rato.")
                continue
            # Ahora toca mirar si el camión puede transportar el peso de la saca sin pasarse del límite de capacidad
            if pesoactualcamion + pesosaca > capacidadcamion:
                print("El camión", i+1, "está siendo despachado con", pesoactualcamion, "kg. Despachando...")
                break
            else:
                # Si el camión no excede el límite de capacidad, sumamos el peso del camión con el peso de la saca
                pesoactualcamion += pesosaca
                print("El peso de la saca es:", pesosaca, "kg. También el peso del camión es:", pesoactualcamion, "kg. Puede transportar tranquilamente.")
                print("Camion", i+1, "despachado con exito.")
                print("todos los camiones han sido cargados y despachados.")
    
    
