# Prmiero hacemos una lista para almacenar usuarios y reservas 
usuarios = []
reservas = []

# Luego hacemos un menú principal para que el usuario pueda elijir alguna opcion
while True:
    print("\nBienvenido querido usuario a nuestro sistema de reservas de hotel")
    print("1. Registrar usuario")
    print("2. Verificar disponibilidad")
    print("3. Reservar habitación")
    print("4. Ver detalles de la reserva")
    print("5. Gestionar reserva")
    print("6. Salir")
    
    opcion = input("Seleccione una opción: ")

    if opcion == "1":
        # Si el usuario elije la opcion 1, procedemos a perdir datos del usuario
        nombre = input("Porfavor, ingrese su nombre: ")
        edad = input("Porfavor, ingrese su edad: ")
        cedula = input("Porfavor, ingrese su cédula: ")
        telefono = input("Porfavor, ingrese su número telefónico: ")
        
        usuario = {
            "nombre": nombre,
            "edad": edad,
            "cedula": cedula,
            "telefono": telefono
        }
        usuarios.append(usuario)
        print("Su Usuario fue registrado con éxito.")

    elif opcion == "2":
        # si el usuario elijio la opcion 2 solicitamos  el numero de la habitacion que desea y las fechas
        habitacion = input("Ingrese el número de la habitación: ")
        fechainicio = input("Ingrese la fecha de inicio (YYYY-MM-DD): ")
        fechafinal = input("Ingrese la fecha de fin (YYYY-MM-DD): ")
        
        disponible = True
        for reserva in reservas:
            if reserva["habitacion"] == habitacion:
                if not (fechafinal < reserva["fecha_inicio"] or fechainicio > reserva["fecha_fin"]):
                    disponible = False
                    break
        
        if disponible:
            print("Perfecto, la habitación está disponible para las fechas seleccionadas.")
        else:
            print("Lo sentimos, la habitación no está disponible para las fechas seleccionadas.")

    elif opcion == "3":
        # Si el usuario elijio la opcion 3 hacemos la reserva de la habitacion
        cedula = input("Porfavor, ingrese su cédula para verificar su usuario: ")
        usuario = None
        for u in usuarios:
            if u["cedula"] == cedula:
                usuario = u
                break
        
        if not usuario:
            print("Usuario no encontrado. Regístrese primero.")
            continue

        habitacion = input("Porfavor, ingrese el número de la habitación: ")
        fechainicio = input("Ingrese la fecha de inicio (YYYY-MM-DD): ")
        fechafinal = input("Ingrese la fecha de fin (YYYY-MM-DD): ")

        disponible = True
        for reserva in reservas:
            if reserva["habitacion"] == habitacion:
                if not (fechafinal < reserva["fechainicio"] or fechainicio > reserva["fechafinal"]):
                    disponible = False
                    break
        
        if disponible:
            reserva = {
                "usuario": usuario,
                "habitacion": habitacion,
                "fechainicio": fechainicio,
                "fechafinal": fechafinal
            }
            reservas.append(reserva)
            print("Reserva realizada con éxito.")
        else:
            print("La habitación no está disponible para las fechas seleccionadas.")
    
    elif opcion == "4":
        # Si el usuario elijio la opcion 4 le pedimos la cedula para mostrarle los detalles de la reserva
        cedula = input("Porfavor, ingrese su cédula para verificar su usuario: ")
        usuarioreservas = [r for r in reservas if r["usuario"]["cedula"] == cedula]
        
        if not usuarioreservas:
            print("Lo sentimos, no se encontraron reservas para este usuario.")
        else:
            for r in usuarioreservas:
                print("Habitación:", r["habitacion"])
                print("Fecha de inicio:", r["fechainicio"])
                print("Fecha de fin:", r["fechafinal"])
                print()

    elif opcion == "5":
        # Si el usuario elijio la opcion 5 le mostramos la opcion de gestionar la reserva pidiendole la cedula nuevamente
        cedula = input("Porfavor, ingrese su cédula para verificar su usuario: ")
        usuarioreservas = [r for r in reservas if r["usuario"]["cedula"] == cedula]
        
        if not usuarioreservas:
            print("No se encontraron reservas para este usuario.")
        else:
            for idx, r in enumerate(usuarioreservas):
                print(f"{idx+1}. Habitación: {r['habitacion']}, Fecha de inicio: {r['fechainicio']}, Fecha de fin: {r['fechafinal']}")
            
            seleccion = int(input("Seleccione el número de la reserva que desea gestionar: ")) - 1
            reserva = usuarioreservas[seleccion]
            
            print("1. Cancelar reserva")
            print("2. Modificar reserva")
            gestion = input("Seleccione una opción: ")

            if gestion == "1":
                reservas.remove(reserva)
                print("Reserva cancelada con éxito.")
            elif gestion == "2":
                nuevafechainicio = input("Porfavor, ingrese la nueva fecha de inicio (YYYY-MM-DD): ")
                nuevafechafinal = input("Porfavor, ingrese la nueva fecha de fin (YYYY-MM-DD): ")
                reserva["fechainicio"] = nuevafechainicio
                reserva["fechafinal"] = nuevafechafinal
                print("Reserva modificada con éxito.")
                #Si el usuario elije la opcion 6 terminamos el bucle diciendole al usuario que esta saliendo del sistema
    elif opcion == "6":
        print("Saliendo del sistema de reservas.")
        break

    else:
        print("Opción no válida. Intente de nuevo.")        

                    
                



          


        
        


